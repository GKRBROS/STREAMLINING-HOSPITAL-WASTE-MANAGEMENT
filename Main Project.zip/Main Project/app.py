from flask import Flask, request, jsonify
import numpy as np
import tensorflow as tf
import cv2
import os
import base64
from PIL import Image
import io

app = Flask(__name__, static_folder='static')

# Load TFLite model
def load_tflite_model():
    interpreter = tf.lite.Interpreter(model_path="model.tflite")
    interpreter.allocate_tensors()
    return interpreter

# Preprocess the image
def preprocess_image(image, target_size=(224, 224)):
    # Resize image
    image = cv2.resize(image, target_size)
    
    # Convert to RGB if needed
    if len(image.shape) == 2:
        image = cv2.cvtColor(image, cv2.COLOR_GRAY2RGB)
    elif image.shape[2] == 4:
        image = cv2.cvtColor(image, cv2.COLOR_RGBA2RGB)
    
    # Denoise image using Non-local Means Denoising
    image = cv2.fastNlMeansDenoisingColored(image, None, 10, 10, 7, 21)
    
    # Normalize pixel values to [0, 1]
    image = image.astype(np.float32) / 255.0
    
    # Expand dimensions to match model input shape [1, height, width, channels]
    image = np.expand_dims(image, axis=0)
    
    return image

# Get prediction from model
def get_prediction(interpreter, processed_image):
    input_details = interpreter.get_input_details()
    output_details = interpreter.get_output_details()
    
    interpreter.set_tensor(input_details[0]['index'], processed_image)
    interpreter.invoke()
    
    output_data = interpreter.get_tensor(output_details[0]['index'])
    return output_data[0]

# Convert the base64 string to image
def base64_to_image(base64_string):
    # Remove the "data:image/jpeg;base64," part if present
    if 'base64,' in base64_string:
        base64_string = base64_string.split('base64,')[1]
    
    # Decode base64 string to image
    image_bytes = base64.b64decode(base64_string)
    image = Image.open(io.BytesIO(image_bytes))
    
    # Convert PIL Image to OpenCV format (numpy array)
    image = np.array(image)
    
    # Convert RGB to BGR if needed (OpenCV uses BGR)
    if len(image.shape) == 3 and image.shape[2] == 3:
        image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
    
    return image

@app.route('/')
def index():
    return app.send_static_file('index.html')

@app.route('/classify', methods=['POST'])
def classify():
    try:
        # Get image data from request
        data = request.json
        image_data = data.get('image')
        
        if not image_data:
            return jsonify({'error': 'No image data provided'}), 400
        
        # Convert base64 to image
        image = base64_to_image(image_data)
        
        # Load model
        interpreter = load_tflite_model()
        
        # Preprocess image
        processed_image = preprocess_image(image)
        
        # Get prediction
        prediction = get_prediction(interpreter, processed_image)
        
        # Map prediction to waste categories
        categories = ["Organic", "Inorganic Recyclable", "Inorganic Non-Recyclable"]
        predicted_class = np.argmax(prediction)
        confidence = float(prediction[predicted_class])
        
        result = {
            'category': categories[predicted_class],
            'confidence': confidence,
            'predictions': {cat: float(pred) for cat, pred in zip(categories, prediction.tolist())}
        }
        
        return jsonify(result)
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    # Make sure the model file exists
    if not os.path.exists('model.tflite'):
        print("Error: model.tflite not found!")
    else:
        app.run(debug=True)